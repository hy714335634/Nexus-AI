#!/usr/bin/env python3
"""
临床试验智能检索与竞品分析Agent

基于Milvus Lite向量数据库的智能Agent，能够自动管理本地向量数据库，
对ClinicalTrials.gov的临床试验数据进行语义检索、竞品分析和智能问答。
集成Amazon Bedrock Cohere Embedding模型实现高质量的多语言文本向量化，
支持自然语言查询、相似试验发现、竞品对比分析等核心功能。
"""

import os
import json
from typing import Dict, Any
from nexus_utils.agent_factory import create_agent_from_prompt_template
from bedrock_agentcore.runtime import BedrockAgentCoreApp
from bedrock_agentcore.runtime.context import RequestContext

from strands.telemetry import StrandsTelemetry
from nexus_utils.config_loader import ConfigLoader

# 加载配置
loader = ConfigLoader()

# 设置环境变量
os.environ["BYPASS_TOOL_CONSENT"] = "true"
otel_endpoint = loader.get_with_env_override(
    "OTEL_EXPORTER_OTLP_ENDPOINT",
    "nexus_ai", "OTEL_EXPORTER_OTLP_ENDPOINT",
    default="http://localhost:4318"
)
os.environ.setdefault("OTEL_EXPORTER_OTLP_ENDPOINT", otel_endpoint)

# 初始化遥测
strands_telemetry = StrandsTelemetry()
strands_telemetry.setup_otlp_exporter()

# 创建 BedrockAgentCoreApp 实例
app = BedrockAgentCoreApp()

# Agent 配置路径
agent_config_path = "generated_agents_prompts/clinical_trial_search_agent/clinical_trial_search_agent_prompt"


# 创建 agent 的通用参数生成方法
def create_clinical_trial_search_agent(
    env: str = "production",
    version: str = "latest",
    model_id: str = "default",
    enable_logging: bool = True
):
    """
    创建临床试验智能检索Agent实例

    Args:
        env: 运行环境（production/development/test）
        version: Agent版本
        model_id: 模型ID（默认使用Claude Sonnet 4.5）
        enable_logging: 是否启用日志记录

    Returns:
        Agent实例
    """
    agent_params = {
        "env": env,
        "version": version,
        "model_id": model_id,
        "enable_logging": enable_logging
    }
    return create_agent_from_prompt_template(
        agent_name=agent_config_path,
        **agent_params
    )


# 使用 agent_factory 创建 agent
clinical_trial_search_agent = create_clinical_trial_search_agent()


# ==================== AgentCore 入口点（必须包含）====================
@app.entrypoint
async def handler(payload: Dict[str, Any], context: RequestContext):
    """
    AgentCore 标准入口点（支持流式响应）

    当部署到 Amazon Bedrock AgentCore 时，AgentCore 会调用此函数处理请求。

    Args:
        payload: AgentCore 传入的请求体，包含:
            - prompt: 用户消息
            - user_id: 用户ID（可选）
            - session_id: 会话ID（可选）
            - media: 媒体文件列表（可选）
        context: 请求上下文，包含:
            - session_id: 会话ID（从 runtimeSessionId header 获取）

    Yields:
        str: 流式响应的文本片段（自动处理流式传输）
    """
    session_id = context.session_id
    print(f"📥 Received payload: {json.dumps(payload, ensure_ascii=False)}, session_id: {session_id}")

    # 提取用户输入
    prompt = payload.get("prompt") or payload.get("message") or payload.get("input", "")

    if not prompt:
        yield "Error: Missing 'prompt' in request"
        return

    print(f"🔄 Processing prompt: {prompt}")

    try:
        # 使用流式响应
        stream = clinical_trial_search_agent.stream_async(prompt)
        async for event in stream:
            # 每个 event 包含流式响应的片段
            print(f"📤 Streaming event: {event}")
            yield event

    except Exception as e:
        print(f"❌ Error: {str(e)}")
        yield f"Error: {str(e)}"


# ==================== 本地运行入口 ====================
if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description='临床试验智能检索与竞品分析Agent',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
使用示例:
  # 本地测试模式（单次查询）
  python clinical_trial_search_agent.py -i "帮我检索所有与PD-1/PD-L1抑制剂治疗非小细胞肺癌相关的III期临床试验"
  
  # 交互式对话模式（多轮对话）
  python clinical_trial_search_agent.py -it
  
  # 竞品分析示例
  python clinical_trial_search_agent.py -i "找到与NCT03215706设计最相似的5个竞品试验"
  
  # 指定环境和版本
  python clinical_trial_search_agent.py -i "检索肺癌临床试验" -e development -v v1.0
  
  # AgentCore部署模式（设置环境变量DOCKER_CONTAINER=1后自动启动）
  DOCKER_CONTAINER=1 python clinical_trial_search_agent.py
        """
    )
    parser.add_argument('-i', '--input', type=str, default=None, help='测试输入内容（单次查询）')
    parser.add_argument('-e', '--env', type=str, default="production", help='指定Agent运行环境（production/development/test）')
    parser.add_argument('-v', '--version', type=str, default="latest", help='指定Agent版本')
    parser.add_argument('-m', '--model', type=str, default="default", help='指定模型ID')
    parser.add_argument('-it', '--interactive', action='store_true', help='启动交互式多轮对话模式')
    parser.add_argument('--init-db', action='store_true', help='初始化Milvus数据库（首次使用时）')
    parser.add_argument('--db-stats', action='store_true', help='显示数据库统计信息')
    args = parser.parse_args()

    # 检查是否在 Docker 容器中运行（AgentCore 部署）
    is_docker = os.environ.get("DOCKER_CONTAINER") == "1"

    if is_docker:
        # AgentCore 部署模式：启动 HTTP 服务器
        print("🚀 启动 AgentCore HTTP 服务器，端口: 8080")
        print("📦 部署模式：Docker容器")
        print("🔗 健康检查端点：http://localhost:8080/health")
        print("🔗 调用端点：http://localhost:8080/invocations")
        app.run()
    elif args.init_db:
        # 数据库初始化模式
        print("🔧 初始化 Milvus Lite 数据库...")
        agent = create_clinical_trial_search_agent(env=args.env, version=args.version, model_id=args.model)
        print(f"✅ Agent 创建成功: {agent.name}")
        
        # 调用数据库初始化工具
        init_query = "请初始化Milvus数据库并显示状态信息"
        print(f"📝 执行初始化: {init_query}")
        try:
            result = agent(init_query)
            print(f"📋 初始化结果:\n{result}")
        except Exception as e:
            print(f"❌ 初始化失败: {e}")
    elif args.db_stats:
        # 数据库统计信息模式
        print("📊 获取数据库统计信息...")
        agent = create_clinical_trial_search_agent(env=args.env, version=args.version, model_id=args.model)
        print(f"✅ Agent 创建成功: {agent.name}")
        
        stats_query = "请显示Milvus数据库的统计信息，包括总试验数、阶段分布、状态分布"
        print(f"📝 查询统计: {stats_query}")
        try:
            result = agent(stats_query)
            print(f"📋 统计结果:\n{result}")
        except Exception as e:
            print(f"❌ 查询失败: {e}")
    elif args.interactive:
        # 交互式对话模式
        agent = create_clinical_trial_search_agent(env=args.env, version=args.version, model_id=args.model)
        print(f"✅ Clinical Trial Search Agent 创建成功: {agent.name}")
        print(f"🔧 运行环境: {args.env}")
        print(f"📦 版本: {args.version}")
        print(f"🤖 模型: {args.model if args.model != 'default' else 'Claude Sonnet 4.5'}")
        print("\n💬 进入交互式对话模式（输入 'quit' 或 'exit' 退出）")
        print("💡 提示: 您可以进行语义检索、竞品分析、多轮对话等操作")
        print("=" * 60)
        
        while True:
            try:
                user_input = input("\nYou: ")
                user_input = user_input.encode('utf-8', errors='ignore').decode('utf-8').strip()
                
                if user_input.lower() in ['quit', 'exit']:
                    print("👋 退出交互式对话")
                    break
                if not user_input:
                    continue
                
                print("\n🤖 Agent:")
                agent(user_input)
                print()
            except KeyboardInterrupt:
                print("\n👋 退出交互式对话")
                break
            except Exception as e:
                print(f"❌ 错误: {e}\n")
    elif args.input:
        # 本地测试模式
        agent = create_clinical_trial_search_agent(env=args.env, version=args.version, model_id=args.model)
        print(f"✅ Clinical Trial Search Agent 创建成功: {agent.name}")
        print(f"🔧 运行环境: {args.env}")
        print(f"📦 版本: {args.version}")
        print(f"🤖 模型: {args.model if args.model != 'default' else 'Claude Sonnet 4.5'}")
        print(f"\n📝 输入: {args.input}")
        print("=" * 60)
        try:
            result = agent(args.input)
            print(f"\n📋 响应:\n{result}")
        except Exception as e:
            print(f"❌ 错误: {e}")
    else:
        # 默认启动服务器
        print("🚀 启动 AgentCore HTTP 服务器，端口: 8080")
        print("💡 提示: 使用 -i 参数进行本地测试，使用 -it 参数启动交互式对话")
        print("💡 使用 --init-db 初始化数据库，使用 --db-stats 查看数据库统计")
        print("🔗 健康检查端点：http://localhost:8080/health")
        print("🔗 调用端点：http://localhost:8080/invocations")
        app.run()
