#!/usr/bin/env python3
"""
语义检索工具

使用Milvus向量数据库执行语义相似度检索
"""

import json
from typing import Dict, List, Any, Optional
from strands import tool


@tool
def semantic_search(
    query_text: str,
    top_k: int = 10,
    similarity_threshold: float = 0.5,
    filters: Optional[Dict[str, Any]] = None,
    db_path: str = ".cache/clinical_trial_search_agent/milvus.db",
    collection_name: str = "clinical_trials",
    region: str = "us-east-1"
) -> str:
    """
    执行语义检索，返回最相似的临床试验
    
    Args:
        query_text: 查询文本
        top_k: 返回Top-K个最相似结果
        similarity_threshold: 相似度阈值（0-1之间，COSINE距离）
        filters: 元数据过滤条件，支持：
            - phase: 试验阶段
            - status: 试验状态
            - sponsor: 主办方
        db_path: 数据库文件路径
        collection_name: Collection名称
        region: AWS区域（用于向量化查询文本）
        
    Returns:
        str: JSON格式的检索结果
    """
    try:
        import boto3
        from pymilvus import MilvusClient
        
        # 1. 向量化查询文本
        bedrock_runtime = boto3.client(
            service_name='bedrock-runtime',
            region_name=region
        )
        
        request_body = {
            "texts": [query_text],
            "input_type": "search_query"
        }
        
        response = bedrock_runtime.invoke_model(
            modelId="cohere.embed-multilingual-v3",
            body=json.dumps(request_body),
            contentType="application/json",
            accept="application/json"
        )
        
        response_body = json.loads(response['body'].read())
        query_vector = response_body.get('embeddings', [[]])[0]
        
        if not query_vector:
            return json.dumps({
                "status": "error",
                "error_type": "vectorization_error",
                "message": "查询文本向量化失败"
            }, ensure_ascii=False, indent=2)
        
        # 2. 连接Milvus数据库
        client = MilvusClient(uri=db_path)
        
        if not client.has_collection(collection_name):
            client.close()
            return json.dumps({
                "status": "error",
                "error_type": "collection_not_found",
                "message": f"Collection {collection_name} 不存在，请先初始化数据库"
            }, ensure_ascii=False, indent=2)
        
        # 3. 构建过滤表达式
        filter_expr = None
        if filters:
            conditions = []
            if "phase" in filters:
                conditions.append(f'phase == "{filters["phase"]}"')
            if "status" in filters:
                conditions.append(f'status == "{filters["status"]}"')
            if "sponsor" in filters:
                conditions.append(f'sponsor like "%{filters["sponsor"]}%"')
            
            if conditions:
                filter_expr = " && ".join(conditions)
        
        # 4. 执行向量检索
        search_params = {
            "metric_type": "COSINE",
            "params": {}
        }
        
        results = client.search(
            collection_name=collection_name,
            data=[query_vector],
            anns_field="embedding_vector",
            search_params=search_params,
            limit=top_k * 2,  # 多检索一些以便过滤
            output_fields=[
                "nct_id", "title", "brief_summary", "eligibility_criteria",
                "phase", "status", "sponsor", "start_date", "completion_date",
                "conditions", "interventions", "url"
            ],
            filter=filter_expr
        )
        
        client.close()
        
        # 5. 处理检索结果
        if not results or not results[0]:
            return json.dumps({
                "status": "success",
                "query": query_text,
                "top_k": top_k,
                "similarity_threshold": similarity_threshold,
                "filters": filters or {},
                "total_results": 0,
                "results": []
            }, ensure_ascii=False, indent=2)
        
        # 过滤相似度阈值
        filtered_results = []
        for hit in results[0]:
            similarity = hit.get("distance", 0.0)
            if similarity >= similarity_threshold:
                entity = hit.get("entity", {})
                filtered_results.append({
                    "nct_id": entity.get("nct_id", ""),
                    "title": entity.get("title", ""),
                    "brief_summary": entity.get("brief_summary", ""),
                    "eligibility_criteria": entity.get("eligibility_criteria", ""),
                    "phase": entity.get("phase", ""),
                    "status": entity.get("status", ""),
                    "sponsor": entity.get("sponsor", ""),
                    "start_date": entity.get("start_date", ""),
                    "completion_date": entity.get("completion_date", ""),
                    "conditions": entity.get("conditions", ""),
                    "interventions": entity.get("interventions", ""),
                    "url": entity.get("url", ""),
                    "similarity_score": round(similarity, 4)
                })
        
        # 限制返回数量
        filtered_results = filtered_results[:top_k]
        
        return json.dumps({
            "status": "success",
            "query": query_text,
            "top_k": top_k,
            "similarity_threshold": similarity_threshold,
            "filters": filters or {},
            "total_results": len(filtered_results),
            "results": filtered_results
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "search_error",
            "message": f"语义检索失败: {str(e)}",
            "query": query_text
        }, ensure_ascii=False, indent=2)


@tool
def find_similar_trials(
    nct_id: str,
    top_k: int = 10,
    similarity_threshold: float = 0.7,
    exclude_self: bool = True,
    db_path: str = ".cache/clinical_trial_search_agent/milvus.db",
    collection_name: str = "clinical_trials"
) -> str:
    """
    根据NCT ID查找相似的临床试验
    
    Args:
        nct_id: 参考试验的NCT ID
        top_k: 返回Top-K个最相似结果
        similarity_threshold: 相似度阈值
        exclude_self: 是否排除自身
        db_path: 数据库文件路径
        collection_name: Collection名称
        
    Returns:
        str: JSON格式的相似试验列表
    """
    try:
        from pymilvus import MilvusClient
        
        # 1. 获取参考试验的向量
        client = MilvusClient(uri=db_path)
        
        if not client.has_collection(collection_name):
            client.close()
            return json.dumps({
                "status": "error",
                "error_type": "collection_not_found",
                "message": f"Collection {collection_name} 不存在"
            }, ensure_ascii=False, indent=2)
        
        # 查询参考试验
        ref_results = client.query(
            collection_name=collection_name,
            filter=f'nct_id == "{nct_id}"',
            output_fields=[
                "nct_id", "title", "brief_summary", "eligibility_criteria",
                "phase", "status", "sponsor", "embedding_vector"
            ],
            limit=1
        )
        
        if not ref_results:
            client.close()
            return json.dumps({
                "status": "error",
                "error_type": "trial_not_found",
                "message": f"NCT ID {nct_id} 不存在于数据库中",
                "nct_id": nct_id
            }, ensure_ascii=False, indent=2)
        
        ref_trial = ref_results[0]
        ref_vector = ref_trial.get("embedding_vector", [])
        
        if not ref_vector:
            client.close()
            return json.dumps({
                "status": "error",
                "error_type": "vector_not_found",
                "message": f"NCT ID {nct_id} 没有向量数据",
                "nct_id": nct_id
            }, ensure_ascii=False, indent=2)
        
        # 2. 执行向量检索
        search_params = {
            "metric_type": "COSINE",
            "params": {}
        }
        
        limit = top_k + 1 if exclude_self else top_k
        
        results = client.search(
            collection_name=collection_name,
            data=[ref_vector],
            anns_field="embedding_vector",
            search_params=search_params,
            limit=limit * 2,
            output_fields=[
                "nct_id", "title", "brief_summary", "eligibility_criteria",
                "phase", "status", "sponsor", "start_date", "completion_date",
                "conditions", "interventions", "url"
            ]
        )
        
        client.close()
        
        # 3. 处理结果
        similar_trials = []
        for hit in results[0]:
            entity = hit.get("entity", {})
            hit_nct_id = entity.get("nct_id", "")
            similarity = hit.get("distance", 0.0)
            
            # 排除自身
            if exclude_self and hit_nct_id == nct_id:
                continue
            
            # 过滤相似度阈值
            if similarity < similarity_threshold:
                continue
            
            similar_trials.append({
                "nct_id": hit_nct_id,
                "title": entity.get("title", ""),
                "brief_summary": entity.get("brief_summary", ""),
                "eligibility_criteria": entity.get("eligibility_criteria", ""),
                "phase": entity.get("phase", ""),
                "status": entity.get("status", ""),
                "sponsor": entity.get("sponsor", ""),
                "start_date": entity.get("start_date", ""),
                "completion_date": entity.get("completion_date", ""),
                "conditions": entity.get("conditions", ""),
                "interventions": entity.get("interventions", ""),
                "url": entity.get("url", ""),
                "similarity_score": round(similarity, 4)
            })
        
        # 限制返回数量
        similar_trials = similar_trials[:top_k]
        
        return json.dumps({
            "status": "success",
            "reference_nct_id": nct_id,
            "reference_title": ref_trial.get("title", ""),
            "reference_phase": ref_trial.get("phase", ""),
            "reference_sponsor": ref_trial.get("sponsor", ""),
            "top_k": top_k,
            "similarity_threshold": similarity_threshold,
            "total_results": len(similar_trials),
            "similar_trials": similar_trials
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "similarity_search_error",
            "message": f"相似试验查找失败: {str(e)}",
            "nct_id": nct_id
        }, ensure_ascii=False, indent=2)


@tool
def hybrid_search(
    query_text: str,
    filters: Dict[str, Any],
    top_k: int = 10,
    similarity_threshold: float = 0.5,
    db_path: str = ".cache/clinical_trial_search_agent/milvus.db",
    collection_name: str = "clinical_trials",
    region: str = "us-east-1"
) -> str:
    """
    混合检索：结合语义检索和元数据过滤
    
    Args:
        query_text: 查询文本
        filters: 必须的元数据过滤条件
        top_k: 返回Top-K个结果
        similarity_threshold: 相似度阈值
        db_path: 数据库文件路径
        collection_name: Collection名称
        region: AWS区域
        
    Returns:
        str: JSON格式的混合检索结果
    """
    try:
        # 直接调用semantic_search并传递过滤条件
        return semantic_search(
            query_text=query_text,
            top_k=top_k,
            similarity_threshold=similarity_threshold,
            filters=filters,
            db_path=db_path,
            collection_name=collection_name,
            region=region
        )
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "hybrid_search_error",
            "message": f"混合检索失败: {str(e)}",
            "query": query_text,
            "filters": filters
        }, ensure_ascii=False, indent=2)


@tool
def get_trial_by_nct_id(
    nct_id: str,
    db_path: str = ".cache/clinical_trial_search_agent/milvus.db",
    collection_name: str = "clinical_trials"
) -> str:
    """
    从数据库中获取指定NCT ID的完整试验信息
    
    Args:
        nct_id: 临床试验NCT ID
        db_path: 数据库文件路径
        collection_name: Collection名称
        
    Returns:
        str: JSON格式的试验详细信息
    """
    try:
        from pymilvus import MilvusClient
        
        client = MilvusClient(uri=db_path)
        
        if not client.has_collection(collection_name):
            client.close()
            return json.dumps({
                "status": "error",
                "error_type": "collection_not_found",
                "message": f"Collection {collection_name} 不存在"
            }, ensure_ascii=False, indent=2)
        
        # 查询试验信息
        results = client.query(
            collection_name=collection_name,
            filter=f'nct_id == "{nct_id}"',
            output_fields=[
                "nct_id", "title", "brief_summary", "eligibility_criteria",
                "phase", "status", "sponsor", "start_date", "completion_date",
                "conditions", "interventions", "url"
            ],
            limit=1
        )
        
        client.close()
        
        if not results:
            return json.dumps({
                "status": "error",
                "error_type": "trial_not_found",
                "message": f"NCT ID {nct_id} 不存在于数据库中",
                "nct_id": nct_id
            }, ensure_ascii=False, indent=2)
        
        trial = results[0]
        
        return json.dumps({
            "status": "success",
            "nct_id": nct_id,
            "trial_data": trial
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "query_error",
            "message": f"查询失败: {str(e)}",
            "nct_id": nct_id
        }, ensure_ascii=False, indent=2)
