#!/usr/bin/env python3
"""
会话管理工具

管理多轮对话的上下文、历史检索结果和引用追溯
"""

import json
import os
import time
from typing import Dict, List, Any, Optional
from pathlib import Path
from strands import tool


@tool
def create_session(
    session_id: str,
    user_info: Optional[Dict[str, Any]] = None,
    session_dir: str = ".cache/clinical_trial_search_agent/sessions"
) -> str:
    """
    创建新的会话
    
    Args:
        session_id: 会话ID（唯一标识符）
        user_info: 用户信息（可选）
        session_dir: 会话存储目录
        
    Returns:
        str: JSON格式的会话创建结果
    """
    try:
        # 创建会话目录
        os.makedirs(session_dir, exist_ok=True)
        
        session_file = os.path.join(session_dir, f"{session_id}.json")
        
        # 检查会话是否已存在
        if os.path.exists(session_file):
            return json.dumps({
                "status": "error",
                "error_type": "session_exists",
                "message": f"会话 {session_id} 已存在",
                "session_id": session_id
            }, ensure_ascii=False, indent=2)
        
        # 创建会话数据
        session_data = {
            "session_id": session_id,
            "created_at": time.time(),
            "updated_at": time.time(),
            "user_info": user_info or {},
            "conversation_history": [],
            "search_history": [],
            "referenced_trials": {},
            "context": {}
        }
        
        # 写入文件
        with open(session_file, 'w', encoding='utf-8') as f:
            json.dump(session_data, f, ensure_ascii=False, indent=2)
        
        return json.dumps({
            "status": "success",
            "session_id": session_id,
            "session_file": session_file,
            "created_at": session_data["created_at"]
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "creation_error",
            "message": f"会话创建失败: {str(e)}",
            "session_id": session_id
        }, ensure_ascii=False, indent=2)


@tool
def get_session(
    session_id: str,
    session_dir: str = ".cache/clinical_trial_search_agent/sessions"
) -> str:
    """
    获取会话数据
    
    Args:
        session_id: 会话ID
        session_dir: 会话存储目录
        
    Returns:
        str: JSON格式的会话数据
    """
    try:
        session_file = os.path.join(session_dir, f"{session_id}.json")
        
        if not os.path.exists(session_file):
            return json.dumps({
                "status": "error",
                "error_type": "session_not_found",
                "message": f"会话 {session_id} 不存在",
                "session_id": session_id
            }, ensure_ascii=False, indent=2)
        
        # 读取会话数据
        with open(session_file, 'r', encoding='utf-8') as f:
            session_data = json.load(f)
        
        return json.dumps({
            "status": "success",
            "session_data": session_data
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "read_error",
            "message": f"会话读取失败: {str(e)}",
            "session_id": session_id
        }, ensure_ascii=False, indent=2)


@tool
def update_session_conversation(
    session_id: str,
    user_message: str,
    assistant_message: str,
    session_dir: str = ".cache/clinical_trial_search_agent/sessions"
) -> str:
    """
    更新会话的对话历史
    
    Args:
        session_id: 会话ID
        user_message: 用户消息
        assistant_message: 助手回复
        session_dir: 会话存储目录
        
    Returns:
        str: JSON格式的更新结果
    """
    try:
        session_file = os.path.join(session_dir, f"{session_id}.json")
        
        if not os.path.exists(session_file):
            return json.dumps({
                "status": "error",
                "error_type": "session_not_found",
                "message": f"会话 {session_id} 不存在",
                "session_id": session_id
            }, ensure_ascii=False, indent=2)
        
        # 读取会话数据
        with open(session_file, 'r', encoding='utf-8') as f:
            session_data = json.load(f)
        
        # 添加对话记录
        conversation_entry = {
            "timestamp": time.time(),
            "user": user_message,
            "assistant": assistant_message
        }
        
        session_data["conversation_history"].append(conversation_entry)
        session_data["updated_at"] = time.time()
        
        # 写回文件
        with open(session_file, 'w', encoding='utf-8') as f:
            json.dump(session_data, f, ensure_ascii=False, indent=2)
        
        return json.dumps({
            "status": "success",
            "session_id": session_id,
            "conversation_count": len(session_data["conversation_history"]),
            "updated_at": session_data["updated_at"]
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "update_error",
            "message": f"对话历史更新失败: {str(e)}",
            "session_id": session_id
        }, ensure_ascii=False, indent=2)


@tool
def add_search_to_session(
    session_id: str,
    query: str,
    search_results: List[Dict[str, Any]],
    search_type: str = "semantic",
    session_dir: str = ".cache/clinical_trial_search_agent/sessions"
) -> str:
    """
    添加检索记录到会话
    
    Args:
        session_id: 会话ID
        query: 查询文本
        search_results: 检索结果列表
        search_type: 检索类型（semantic/competitive/hybrid）
        session_dir: 会话存储目录
        
    Returns:
        str: JSON格式的更新结果
    """
    try:
        session_file = os.path.join(session_dir, f"{session_id}.json")
        
        if not os.path.exists(session_file):
            return json.dumps({
                "status": "error",
                "error_type": "session_not_found",
                "message": f"会话 {session_id} 不存在",
                "session_id": session_id
            }, ensure_ascii=False, indent=2)
        
        # 读取会话数据
        with open(session_file, 'r', encoding='utf-8') as f:
            session_data = json.load(f)
        
        # 添加检索记录
        search_entry = {
            "timestamp": time.time(),
            "query": query,
            "search_type": search_type,
            "result_count": len(search_results),
            "results": search_results
        }
        
        session_data["search_history"].append(search_entry)
        
        # 更新引用的试验
        for result in search_results:
            nct_id = result.get("nct_id")
            if nct_id:
                if nct_id not in session_data["referenced_trials"]:
                    session_data["referenced_trials"][nct_id] = {
                        "title": result.get("title", ""),
                        "url": result.get("url", ""),
                        "first_mentioned": time.time(),
                        "mention_count": 1
                    }
                else:
                    session_data["referenced_trials"][nct_id]["mention_count"] += 1
        
        session_data["updated_at"] = time.time()
        
        # 写回文件
        with open(session_file, 'w', encoding='utf-8') as f:
            json.dump(session_data, f, ensure_ascii=False, indent=2)
        
        return json.dumps({
            "status": "success",
            "session_id": session_id,
            "search_count": len(session_data["search_history"]),
            "referenced_trials_count": len(session_data["referenced_trials"]),
            "updated_at": session_data["updated_at"]
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "update_error",
            "message": f"检索记录添加失败: {str(e)}",
            "session_id": session_id
        }, ensure_ascii=False, indent=2)


@tool
def get_session_context(
    session_id: str,
    include_history: bool = True,
    max_history_items: int = 10,
    session_dir: str = ".cache/clinical_trial_search_agent/sessions"
) -> str:
    """
    获取会话上下文（用于多轮对话）
    
    Args:
        session_id: 会话ID
        include_history: 是否包含历史记录
        max_history_items: 最大历史记录数
        session_dir: 会话存储目录
        
    Returns:
        str: JSON格式的会话上下文
    """
    try:
        session_file = os.path.join(session_dir, f"{session_id}.json")
        
        if not os.path.exists(session_file):
            return json.dumps({
                "status": "error",
                "error_type": "session_not_found",
                "message": f"会话 {session_id} 不存在",
                "session_id": session_id
            }, ensure_ascii=False, indent=2)
        
        # 读取会话数据
        with open(session_file, 'r', encoding='utf-8') as f:
            session_data = json.load(f)
        
        context = {
            "session_id": session_id,
            "created_at": session_data["created_at"],
            "updated_at": session_data["updated_at"],
            "referenced_trials": session_data["referenced_trials"],
            "context": session_data.get("context", {})
        }
        
        if include_history:
            # 获取最近的对话历史
            conversation_history = session_data.get("conversation_history", [])
            context["recent_conversations"] = conversation_history[-max_history_items:]
            
            # 获取最近的检索历史
            search_history = session_data.get("search_history", [])
            context["recent_searches"] = search_history[-max_history_items:]
        
        return json.dumps({
            "status": "success",
            "context": context
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "context_error",
            "message": f"上下文获取失败: {str(e)}",
            "session_id": session_id
        }, ensure_ascii=False, indent=2)


@tool
def update_session_context(
    session_id: str,
    context_updates: Dict[str, Any],
    session_dir: str = ".cache/clinical_trial_search_agent/sessions"
) -> str:
    """
    更新会话上下文（自定义键值对）
    
    Args:
        session_id: 会话ID
        context_updates: 要更新的上下文数据
        session_dir: 会话存储目录
        
    Returns:
        str: JSON格式的更新结果
    """
    try:
        session_file = os.path.join(session_dir, f"{session_id}.json")
        
        if not os.path.exists(session_file):
            return json.dumps({
                "status": "error",
                "error_type": "session_not_found",
                "message": f"会话 {session_id} 不存在",
                "session_id": session_id
            }, ensure_ascii=False, indent=2)
        
        # 读取会话数据
        with open(session_file, 'r', encoding='utf-8') as f:
            session_data = json.load(f)
        
        # 更新上下文
        if "context" not in session_data:
            session_data["context"] = {}
        
        session_data["context"].update(context_updates)
        session_data["updated_at"] = time.time()
        
        # 写回文件
        with open(session_file, 'w', encoding='utf-8') as f:
            json.dump(session_data, f, ensure_ascii=False, indent=2)
        
        return json.dumps({
            "status": "success",
            "session_id": session_id,
            "context_keys": list(session_data["context"].keys()),
            "updated_at": session_data["updated_at"]
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "update_error",
            "message": f"上下文更新失败: {str(e)}",
            "session_id": session_id
        }, ensure_ascii=False, indent=2)


@tool
def list_sessions(
    session_dir: str = ".cache/clinical_trial_search_agent/sessions",
    active_only: bool = False,
    max_age_hours: int = 168  # 7天
) -> str:
    """
    列出所有会话
    
    Args:
        session_dir: 会话存储目录
        active_only: 仅列出活跃会话
        max_age_hours: 活跃会话的最大年龄（小时）
        
    Returns:
        str: JSON格式的会话列表
    """
    try:
        if not os.path.exists(session_dir):
            return json.dumps({
                "status": "success",
                "total_sessions": 0,
                "sessions": []
            }, ensure_ascii=False, indent=2)
        
        sessions = []
        current_time = time.time()
        max_age_seconds = max_age_hours * 3600
        
        for filename in os.listdir(session_dir):
            if filename.endswith('.json'):
                session_file = os.path.join(session_dir, filename)
                
                try:
                    with open(session_file, 'r', encoding='utf-8') as f:
                        session_data = json.load(f)
                    
                    session_age = current_time - session_data.get("updated_at", 0)
                    
                    if active_only and session_age > max_age_seconds:
                        continue
                    
                    sessions.append({
                        "session_id": session_data.get("session_id"),
                        "created_at": session_data.get("created_at"),
                        "updated_at": session_data.get("updated_at"),
                        "age_hours": round(session_age / 3600, 2),
                        "conversation_count": len(session_data.get("conversation_history", [])),
                        "search_count": len(session_data.get("search_history", [])),
                        "referenced_trials_count": len(session_data.get("referenced_trials", {}))
                    })
                except:
                    continue
        
        # 按更新时间排序
        sessions.sort(key=lambda x: x["updated_at"], reverse=True)
        
        return json.dumps({
            "status": "success",
            "total_sessions": len(sessions),
            "active_only": active_only,
            "max_age_hours": max_age_hours if active_only else None,
            "sessions": sessions
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "list_error",
            "message": f"会话列表获取失败: {str(e)}"
        }, ensure_ascii=False, indent=2)


@tool
def delete_session(
    session_id: str,
    session_dir: str = ".cache/clinical_trial_search_agent/sessions"
) -> str:
    """
    删除会话
    
    Args:
        session_id: 会话ID
        session_dir: 会话存储目录
        
    Returns:
        str: JSON格式的删除结果
    """
    try:
        session_file = os.path.join(session_dir, f"{session_id}.json")
        
        if not os.path.exists(session_file):
            return json.dumps({
                "status": "error",
                "error_type": "session_not_found",
                "message": f"会话 {session_id} 不存在",
                "session_id": session_id
            }, ensure_ascii=False, indent=2)
        
        # 删除文件
        os.remove(session_file)
        
        return json.dumps({
            "status": "success",
            "session_id": session_id,
            "message": "会话已删除"
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "deletion_error",
            "message": f"会话删除失败: {str(e)}",
            "session_id": session_id
        }, ensure_ascii=False, indent=2)


@tool
def cleanup_old_sessions(
    max_age_hours: int = 168,  # 7天
    session_dir: str = ".cache/clinical_trial_search_agent/sessions"
) -> str:
    """
    清理过期的会话
    
    Args:
        max_age_hours: 会话最大保留时间（小时）
        session_dir: 会话存储目录
        
    Returns:
        str: JSON格式的清理结果
    """
    try:
        if not os.path.exists(session_dir):
            return json.dumps({
                "status": "success",
                "deleted_count": 0,
                "message": "会话目录不存在"
            }, ensure_ascii=False, indent=2)
        
        current_time = time.time()
        max_age_seconds = max_age_hours * 3600
        deleted_count = 0
        deleted_sessions = []
        
        for filename in os.listdir(session_dir):
            if filename.endswith('.json'):
                session_file = os.path.join(session_dir, filename)
                
                try:
                    with open(session_file, 'r', encoding='utf-8') as f:
                        session_data = json.load(f)
                    
                    session_age = current_time - session_data.get("updated_at", 0)
                    
                    if session_age > max_age_seconds:
                        os.remove(session_file)
                        deleted_count += 1
                        deleted_sessions.append(session_data.get("session_id"))
                except:
                    continue
        
        return json.dumps({
            "status": "success",
            "max_age_hours": max_age_hours,
            "deleted_count": deleted_count,
            "deleted_sessions": deleted_sessions
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "cleanup_error",
            "message": f"会话清理失败: {str(e)}"
        }, ensure_ascii=False, indent=2)
