#!/usr/bin/env python3
"""
临床试验数据采集工具

从ClinicalTrials.gov REST API v2采集临床试验数据
"""

import json
import requests
import time
from typing import Dict, List, Any, Optional
from strands import tool


@tool
def search_clinical_trials(
    query: str,
    max_results: int = 100,
    filters: Optional[Dict[str, Any]] = None
) -> str:
    """
    从ClinicalTrials.gov搜索临床试验数据
    
    Args:
        query: 搜索关键词（疾病、靶点、药物等）
        max_results: 最大返回结果数
        filters: 过滤条件，支持：
            - phase: 试验阶段（如"PHASE3"）
            - status: 试验状态（如"RECRUITING"）
            - sponsor: 主办方名称
            - start_date: 开始日期范围
            
    Returns:
        str: JSON格式的临床试验数据列表
    """
    try:
        base_url = "https://clinicaltrials.gov/api/v2/studies"
        
        # 构建查询参数
        params = {
            "query.term": query,
            "pageSize": min(max_results, 1000),  # API最大1000
            "format": "json"
        }
        
        # 添加过滤条件
        if filters:
            if "phase" in filters:
                params["query.phase"] = filters["phase"]
            if "status" in filters:
                params["query.overallStatus"] = filters["status"]
            if "sponsor" in filters:
                params["query.leadSponsor"] = filters["sponsor"]
        
        # 发送请求
        response = requests.get(base_url, params=params, timeout=30)
        response.raise_for_status()
        
        data = response.json()
        studies = data.get("studies", [])
        
        # 提取关键字段
        results = []
        for study in studies[:max_results]:
            protocol_section = study.get("protocolSection", {})
            identification = protocol_section.get("identificationModule", {})
            status_module = protocol_section.get("statusModule", {})
            design_module = protocol_section.get("designModule", {})
            eligibility = protocol_section.get("eligibilityModule", {})
            description = protocol_section.get("descriptionModule", {})
            conditions = protocol_section.get("conditionsModule", {})
            interventions = protocol_section.get("armsInterventionsModule", {})
            
            trial_data = {
                "nct_id": identification.get("nctId", ""),
                "title": identification.get("officialTitle") or identification.get("briefTitle", ""),
                "brief_summary": description.get("briefSummary", ""),
                "eligibility_criteria": eligibility.get("eligibilityCriteria", ""),
                "phase": design_module.get("phases", ["N/A"])[0] if design_module.get("phases") else "N/A",
                "status": status_module.get("overallStatus", ""),
                "sponsor": protocol_section.get("sponsorCollaboratorsModule", {}).get("leadSponsor", {}).get("name", ""),
                "start_date": status_module.get("startDateStruct", {}).get("date", ""),
                "completion_date": status_module.get("completionDateStruct", {}).get("date", ""),
                "conditions": conditions.get("conditions", []),
                "interventions": [
                    intervention.get("name", "")
                    for intervention in interventions.get("interventions", [])
                ],
                "url": f"https://clinicaltrials.gov/study/{identification.get('nctId', '')}"
            }
            results.append(trial_data)
        
        return json.dumps({
            "status": "success",
            "total_results": len(results),
            "query": query,
            "filters": filters or {},
            "timestamp": time.time(),
            "results": results
        }, ensure_ascii=False, indent=2)
        
    except requests.exceptions.RequestException as e:
        return json.dumps({
            "status": "error",
            "error_type": "network_error",
            "message": f"网络请求失败: {str(e)}",
            "query": query
        }, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "unknown_error",
            "message": f"未知错误: {str(e)}",
            "query": query
        }, ensure_ascii=False, indent=2)


@tool
def fetch_trial_by_nct_id(nct_id: str) -> str:
    """
    根据NCT ID获取单个临床试验的详细信息
    
    Args:
        nct_id: 临床试验NCT ID（如NCT03215706）
        
    Returns:
        str: JSON格式的临床试验详细数据
    """
    try:
        base_url = f"https://clinicaltrials.gov/api/v2/studies/{nct_id}"
        
        response = requests.get(base_url, params={"format": "json"}, timeout=30)
        response.raise_for_status()
        
        study = response.json()
        protocol_section = study.get("protocolSection", {})
        identification = protocol_section.get("identificationModule", {})
        status_module = protocol_section.get("statusModule", {})
        design_module = protocol_section.get("designModule", {})
        eligibility = protocol_section.get("eligibilityModule", {})
        description = protocol_section.get("descriptionModule", {})
        conditions = protocol_section.get("conditionsModule", {})
        interventions = protocol_section.get("armsInterventionsModule", {})
        
        trial_data = {
            "nct_id": identification.get("nctId", ""),
            "title": identification.get("officialTitle") or identification.get("briefTitle", ""),
            "brief_summary": description.get("briefSummary", ""),
            "detailed_description": description.get("detailedDescription", ""),
            "eligibility_criteria": eligibility.get("eligibilityCriteria", ""),
            "phase": design_module.get("phases", ["N/A"])[0] if design_module.get("phases") else "N/A",
            "status": status_module.get("overallStatus", ""),
            "sponsor": protocol_section.get("sponsorCollaboratorsModule", {}).get("leadSponsor", {}).get("name", ""),
            "start_date": status_module.get("startDateStruct", {}).get("date", ""),
            "completion_date": status_module.get("completionDateStruct", {}).get("date", ""),
            "conditions": conditions.get("conditions", []),
            "interventions": [
                {
                    "type": intervention.get("type", ""),
                    "name": intervention.get("name", ""),
                    "description": intervention.get("description", "")
                }
                for intervention in interventions.get("interventions", [])
            ],
            "url": f"https://clinicaltrials.gov/study/{nct_id}"
        }
        
        return json.dumps({
            "status": "success",
            "nct_id": nct_id,
            "timestamp": time.time(),
            "data": trial_data
        }, ensure_ascii=False, indent=2)
        
    except requests.exceptions.HTTPError as e:
        if e.response.status_code == 404:
            return json.dumps({
                "status": "error",
                "error_type": "not_found",
                "message": f"NCT ID {nct_id} 不存在",
                "nct_id": nct_id
            }, ensure_ascii=False, indent=2)
        else:
            return json.dumps({
                "status": "error",
                "error_type": "http_error",
                "message": f"HTTP错误: {str(e)}",
                "nct_id": nct_id
            }, ensure_ascii=False, indent=2)
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "unknown_error",
            "message": f"未知错误: {str(e)}",
            "nct_id": nct_id
        }, ensure_ascii=False, indent=2)


@tool
def batch_fetch_trials(nct_ids: List[str]) -> str:
    """
    批量获取多个临床试验的详细信息
    
    Args:
        nct_ids: NCT ID列表
        
    Returns:
        str: JSON格式的批量结果
    """
    try:
        results = []
        errors = []
        
        for nct_id in nct_ids:
            result_str = fetch_trial_by_nct_id(nct_id)
            result = json.loads(result_str)
            
            if result["status"] == "success":
                results.append(result["data"])
            else:
                errors.append({
                    "nct_id": nct_id,
                    "error": result.get("message", "未知错误")
                })
        
        return json.dumps({
            "status": "success",
            "total_requested": len(nct_ids),
            "successful": len(results),
            "failed": len(errors),
            "timestamp": time.time(),
            "results": results,
            "errors": errors if errors else None
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "batch_error",
            "message": f"批量获取失败: {str(e)}",
            "total_requested": len(nct_ids)
        }, ensure_ascii=False, indent=2)


@tool
def validate_nct_id(nct_id: str) -> str:
    """
    验证NCT ID格式是否正确
    
    Args:
        nct_id: 待验证的NCT ID
        
    Returns:
        str: JSON格式的验证结果
    """
    try:
        import re
        
        # NCT ID格式: NCT + 8位数字
        pattern = r'^NCT\d{8}$'
        is_valid = bool(re.match(pattern, nct_id))
        
        result = {
            "nct_id": nct_id,
            "is_valid": is_valid,
            "format": "NCT + 8位数字"
        }
        
        if not is_valid:
            result["message"] = "NCT ID格式不正确，应为NCT后跟8位数字"
        
        return json.dumps(result, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "nct_id": nct_id,
            "is_valid": False,
            "error": str(e)
        }, ensure_ascii=False, indent=2)
