#!/usr/bin/env python3
"""
Cohere向量化工具

使用Amazon Bedrock Cohere Embed Multilingual v3.0模型进行文本向量化
"""

import json
import boto3
from typing import List, Dict, Any, Optional
from strands import tool


@tool
def vectorize_text(
    text: str,
    input_type: str = "search_document",
    region: str = "us-east-1"
) -> str:
    """
    使用Bedrock Cohere模型向量化单个文本
    
    Args:
        text: 要向量化的文本
        input_type: 输入类型（search_document用于存储，search_query用于查询）
        region: AWS区域
        
    Returns:
        str: JSON格式的向量化结果
    """
    try:
        if not text or not text.strip():
            return json.dumps({
                "status": "error",
                "error_type": "invalid_input",
                "message": "文本内容不能为空"
            }, ensure_ascii=False, indent=2)
        
        # 创建Bedrock客户端
        bedrock_runtime = boto3.client(
            service_name='bedrock-runtime',
            region_name=region
        )
        
        # 构建请求体
        request_body = {
            "texts": [text],
            "input_type": input_type
        }
        
        # 调用Cohere Embed模型
        model_id = "cohere.embed-multilingual-v3"
        response = bedrock_runtime.invoke_model(
            modelId=model_id,
            body=json.dumps(request_body),
            contentType="application/json",
            accept="application/json"
        )
        
        # 解析响应
        response_body = json.loads(response['body'].read())
        embeddings = response_body.get('embeddings', [])
        
        if not embeddings:
            return json.dumps({
                "status": "error",
                "error_type": "empty_response",
                "message": "向量化返回空结果"
            }, ensure_ascii=False, indent=2)
        
        vector = embeddings[0]
        
        return json.dumps({
            "status": "success",
            "text_length": len(text),
            "vector_dimension": len(vector),
            "model_id": model_id,
            "input_type": input_type,
            "embedding": vector
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "vectorization_error",
            "message": f"向量化失败: {str(e)}",
            "text_preview": text[:100] if text else ""
        }, ensure_ascii=False, indent=2)


@tool
def batch_vectorize_texts(
    texts: List[str],
    input_type: str = "search_document",
    region: str = "us-east-1",
    batch_size: int = 50
) -> str:
    """
    批量向量化多个文本
    
    Args:
        texts: 要向量化的文本列表
        input_type: 输入类型（search_document用于存储，search_query用于查询）
        region: AWS区域
        batch_size: 每批处理的文本数量（最大96）
        
    Returns:
        str: JSON格式的批量向量化结果
    """
    try:
        if not texts:
            return json.dumps({
                "status": "error",
                "error_type": "invalid_input",
                "message": "文本列表不能为空"
            }, ensure_ascii=False, indent=2)
        
        # 创建Bedrock客户端
        bedrock_runtime = boto3.client(
            service_name='bedrock-runtime',
            region_name=region
        )
        
        model_id = "cohere.embed-multilingual-v3"
        all_embeddings = []
        batch_size = min(batch_size, 96)  # Cohere最大96
        
        # 分批处理
        for i in range(0, len(texts), batch_size):
            batch_texts = texts[i:i + batch_size]
            
            # 过滤空文本
            valid_texts = [t for t in batch_texts if t and t.strip()]
            if not valid_texts:
                continue
            
            # 构建请求体
            request_body = {
                "texts": valid_texts,
                "input_type": input_type
            }
            
            # 调用Cohere Embed模型
            response = bedrock_runtime.invoke_model(
                modelId=model_id,
                body=json.dumps(request_body),
                contentType="application/json",
                accept="application/json"
            )
            
            # 解析响应
            response_body = json.loads(response['body'].read())
            embeddings = response_body.get('embeddings', [])
            all_embeddings.extend(embeddings)
        
        return json.dumps({
            "status": "success",
            "total_texts": len(texts),
            "vectorized_count": len(all_embeddings),
            "vector_dimension": len(all_embeddings[0]) if all_embeddings else 0,
            "model_id": model_id,
            "input_type": input_type,
            "embeddings": all_embeddings
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "batch_vectorization_error",
            "message": f"批量向量化失败: {str(e)}",
            "total_texts": len(texts)
        }, ensure_ascii=False, indent=2)


@tool
def vectorize_trial_data(
    trial_data: Dict[str, Any],
    region: str = "us-east-1"
) -> str:
    """
    向量化临床试验数据（标题+摘要+入排标准）
    
    Args:
        trial_data: 临床试验数据字典，必须包含title、brief_summary、eligibility_criteria
        region: AWS区域
        
    Returns:
        str: JSON格式的向量化结果
    """
    try:
        # 提取关键文本字段
        title = trial_data.get("title", "")
        summary = trial_data.get("brief_summary", "")
        eligibility = trial_data.get("eligibility_criteria", "")
        
        # 组合文本（标题权重更高，重复两次）
        combined_text = f"{title}. {title}. {summary} {eligibility}"
        
        # 向量化
        result_str = vectorize_text(
            text=combined_text,
            input_type="search_document",
            region=region
        )
        
        result = json.loads(result_str)
        
        if result["status"] == "success":
            return json.dumps({
                "status": "success",
                "nct_id": trial_data.get("nct_id", ""),
                "combined_text_length": len(combined_text),
                "vector_dimension": result["vector_dimension"],
                "embedding": result["embedding"]
            }, ensure_ascii=False, indent=2)
        else:
            return result_str
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "trial_vectorization_error",
            "message": f"临床试验数据向量化失败: {str(e)}",
            "nct_id": trial_data.get("nct_id", "")
        }, ensure_ascii=False, indent=2)


@tool
def batch_vectorize_trials(
    trials: List[Dict[str, Any]],
    region: str = "us-east-1",
    batch_size: int = 50
) -> str:
    """
    批量向量化多个临床试验数据
    
    Args:
        trials: 临床试验数据列表
        region: AWS区域
        batch_size: 每批处理的数量
        
    Returns:
        str: JSON格式的批量向量化结果
    """
    try:
        if not trials:
            return json.dumps({
                "status": "error",
                "error_type": "invalid_input",
                "message": "临床试验列表不能为空"
            }, ensure_ascii=False, indent=2)
        
        # 准备文本列表
        texts = []
        nct_ids = []
        for trial in trials:
            title = trial.get("title", "")
            summary = trial.get("brief_summary", "")
            eligibility = trial.get("eligibility_criteria", "")
            combined_text = f"{title}. {title}. {summary} {eligibility}"
            texts.append(combined_text)
            nct_ids.append(trial.get("nct_id", ""))
        
        # 批量向量化
        result_str = batch_vectorize_texts(
            texts=texts,
            input_type="search_document",
            region=region,
            batch_size=batch_size
        )
        
        result = json.loads(result_str)
        
        if result["status"] == "success":
            # 将向量与NCT ID关联
            trial_vectors = []
            for i, embedding in enumerate(result["embeddings"]):
                trial_vectors.append({
                    "nct_id": nct_ids[i],
                    "embedding": embedding
                })
            
            return json.dumps({
                "status": "success",
                "total_trials": len(trials),
                "vectorized_count": len(trial_vectors),
                "vector_dimension": result["vector_dimension"],
                "trial_vectors": trial_vectors
            }, ensure_ascii=False, indent=2)
        else:
            return result_str
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "batch_trial_vectorization_error",
            "message": f"批量临床试验向量化失败: {str(e)}",
            "total_trials": len(trials)
        }, ensure_ascii=False, indent=2)
