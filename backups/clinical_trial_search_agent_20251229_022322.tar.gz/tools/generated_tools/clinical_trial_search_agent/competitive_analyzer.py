#!/usr/bin/env python3
"""
竞品分析工具

生成临床试验竞品对比分析报告
"""

import json
from typing import List, Dict, Any, Optional
from strands import tool


@tool
def analyze_trial_competition(
    reference_nct_id: str,
    competitor_nct_ids: Optional[List[str]] = None,
    auto_discover: bool = True,
    top_k: int = 5,
    similarity_threshold: float = 0.7,
    db_path: str = ".cache/clinical_trial_search_agent/milvus.db",
    collection_name: str = "clinical_trials"
) -> str:
    """
    生成临床试验竞品分析报告
    
    Args:
        reference_nct_id: 参考试验的NCT ID
        competitor_nct_ids: 指定的竞品NCT ID列表（可选）
        auto_discover: 是否自动发现相似竞品
        top_k: 自动发现时返回的竞品数量
        similarity_threshold: 自动发现的相似度阈值
        db_path: 数据库文件路径
        collection_name: Collection名称
        
    Returns:
        str: JSON格式的竞品分析报告
    """
    try:
        from pymilvus import MilvusClient
        
        client = MilvusClient(uri=db_path)
        
        if not client.has_collection(collection_name):
            client.close()
            return json.dumps({
                "status": "error",
                "error_type": "collection_not_found",
                "message": f"Collection {collection_name} 不存在"
            }, ensure_ascii=False, indent=2)
        
        # 1. 获取参考试验信息
        ref_results = client.query(
            collection_name=collection_name,
            filter=f'nct_id == "{reference_nct_id}"',
            output_fields=[
                "nct_id", "title", "brief_summary", "eligibility_criteria",
                "phase", "status", "sponsor", "start_date", "completion_date",
                "conditions", "interventions", "url", "embedding_vector"
            ],
            limit=1
        )
        
        if not ref_results:
            client.close()
            return json.dumps({
                "status": "error",
                "error_type": "trial_not_found",
                "message": f"参考试验 {reference_nct_id} 不存在",
                "reference_nct_id": reference_nct_id
            }, ensure_ascii=False, indent=2)
        
        ref_trial = ref_results[0]
        ref_vector = ref_trial.get("embedding_vector", [])
        
        # 2. 获取竞品试验列表
        competitors = []
        
        if auto_discover and ref_vector:
            # 自动发现相似竞品
            search_params = {
                "metric_type": "COSINE",
                "params": {}
            }
            
            search_results = client.search(
                collection_name=collection_name,
                data=[ref_vector],
                anns_field="embedding_vector",
                search_params=search_params,
                limit=(top_k + 1) * 2,
                output_fields=[
                    "nct_id", "title", "brief_summary", "eligibility_criteria",
                    "phase", "status", "sponsor", "start_date", "completion_date",
                    "conditions", "interventions", "url"
                ]
            )
            
            for hit in search_results[0]:
                entity = hit.get("entity", {})
                hit_nct_id = entity.get("nct_id", "")
                similarity = hit.get("distance", 0.0)
                
                # 排除自身
                if hit_nct_id == reference_nct_id:
                    continue
                
                # 过滤相似度阈值
                if similarity < similarity_threshold:
                    continue
                
                entity["similarity_score"] = round(similarity, 4)
                competitors.append(entity)
                
                if len(competitors) >= top_k:
                    break
        
        if competitor_nct_ids:
            # 获取指定的竞品试验
            for comp_nct_id in competitor_nct_ids:
                if comp_nct_id == reference_nct_id:
                    continue
                
                comp_results = client.query(
                    collection_name=collection_name,
                    filter=f'nct_id == "{comp_nct_id}"',
                    output_fields=[
                        "nct_id", "title", "brief_summary", "eligibility_criteria",
                        "phase", "status", "sponsor", "start_date", "completion_date",
                        "conditions", "interventions", "url"
                    ],
                    limit=1
                )
                
                if comp_results:
                    comp_trial = comp_results[0]
                    # 如果已经在自动发现列表中，跳过
                    if not any(c.get("nct_id") == comp_nct_id for c in competitors):
                        comp_trial["similarity_score"] = None  # 指定的竞品没有相似度分数
                        competitors.append(comp_trial)
        
        client.close()
        
        if not competitors:
            return json.dumps({
                "status": "success",
                "reference_trial": {
                    "nct_id": ref_trial.get("nct_id"),
                    "title": ref_trial.get("title"),
                    "phase": ref_trial.get("phase"),
                    "sponsor": ref_trial.get("sponsor"),
                    "url": ref_trial.get("url")
                },
                "total_competitors": 0,
                "competitors": [],
                "analysis": {
                    "message": "未找到符合条件的竞品试验"
                }
            }, ensure_ascii=False, indent=2)
        
        # 3. 生成对比分析
        analysis = {
            "phase_comparison": {},
            "status_comparison": {},
            "sponsor_analysis": {},
            "timeline_analysis": {},
            "intervention_overlap": {},
            "condition_overlap": {}
        }
        
        # 阶段对比
        ref_phase = ref_trial.get("phase", "N/A")
        phase_dist = {}
        for comp in competitors:
            phase = comp.get("phase", "N/A")
            phase_dist[phase] = phase_dist.get(phase, 0) + 1
        
        analysis["phase_comparison"] = {
            "reference_phase": ref_phase,
            "competitor_phases": phase_dist,
            "same_phase_count": phase_dist.get(ref_phase, 0)
        }
        
        # 状态对比
        ref_status = ref_trial.get("status", "")
        status_dist = {}
        for comp in competitors:
            status = comp.get("status", "")
            status_dist[status] = status_dist.get(status, 0) + 1
        
        analysis["status_comparison"] = {
            "reference_status": ref_status,
            "competitor_statuses": status_dist
        }
        
        # 主办方分析
        ref_sponsor = ref_trial.get("sponsor", "")
        sponsors = {}
        for comp in competitors:
            sponsor = comp.get("sponsor", "")
            if sponsor:
                sponsors[sponsor] = sponsors.get(sponsor, 0) + 1
        
        analysis["sponsor_analysis"] = {
            "reference_sponsor": ref_sponsor,
            "competitor_sponsors": sponsors,
            "unique_sponsors": len(sponsors),
            "same_sponsor_count": sponsors.get(ref_sponsor, 0)
        }
        
        # 时间线分析
        ref_start = ref_trial.get("start_date", "")
        ref_completion = ref_trial.get("completion_date", "")
        
        earlier_starts = 0
        later_starts = 0
        for comp in competitors:
            comp_start = comp.get("start_date", "")
            if comp_start and ref_start:
                if comp_start < ref_start:
                    earlier_starts += 1
                elif comp_start > ref_start:
                    later_starts += 1
        
        analysis["timeline_analysis"] = {
            "reference_start_date": ref_start,
            "reference_completion_date": ref_completion,
            "competitors_started_earlier": earlier_starts,
            "competitors_started_later": later_starts
        }
        
        # 干预措施重叠
        ref_interventions = set(ref_trial.get("interventions", "").split(", "))
        intervention_overlap = {}
        for comp in competitors:
            comp_interventions = set(comp.get("interventions", "").split(", "))
            overlap = ref_interventions & comp_interventions
            if overlap:
                intervention_overlap[comp.get("nct_id")] = list(overlap)
        
        analysis["intervention_overlap"] = {
            "reference_interventions": list(ref_interventions),
            "overlapping_trials": intervention_overlap,
            "overlap_count": len(intervention_overlap)
        }
        
        # 适应症重叠
        ref_conditions = set(ref_trial.get("conditions", "").split(", "))
        condition_overlap = {}
        for comp in competitors:
            comp_conditions = set(comp.get("conditions", "").split(", "))
            overlap = ref_conditions & comp_conditions
            if overlap:
                condition_overlap[comp.get("nct_id")] = list(overlap)
        
        analysis["condition_overlap"] = {
            "reference_conditions": list(ref_conditions),
            "overlapping_trials": condition_overlap,
            "overlap_count": len(condition_overlap)
        }
        
        # 4. 构建完整报告
        report = {
            "status": "success",
            "reference_trial": {
                "nct_id": ref_trial.get("nct_id"),
                "title": ref_trial.get("title"),
                "brief_summary": ref_trial.get("brief_summary"),
                "phase": ref_trial.get("phase"),
                "status": ref_trial.get("status"),
                "sponsor": ref_trial.get("sponsor"),
                "start_date": ref_trial.get("start_date"),
                "completion_date": ref_trial.get("completion_date"),
                "conditions": ref_trial.get("conditions"),
                "interventions": ref_trial.get("interventions"),
                "url": ref_trial.get("url")
            },
            "total_competitors": len(competitors),
            "competitors": [
                {
                    "nct_id": comp.get("nct_id"),
                    "title": comp.get("title"),
                    "brief_summary": comp.get("brief_summary"),
                    "phase": comp.get("phase"),
                    "status": comp.get("status"),
                    "sponsor": comp.get("sponsor"),
                    "start_date": comp.get("start_date"),
                    "completion_date": comp.get("completion_date"),
                    "conditions": comp.get("conditions"),
                    "interventions": comp.get("interventions"),
                    "url": comp.get("url"),
                    "similarity_score": comp.get("similarity_score")
                }
                for comp in competitors
            ],
            "analysis": analysis,
            "discovery_method": "auto" if auto_discover else "manual"
        }
        
        return json.dumps(report, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "analysis_error",
            "message": f"竞品分析失败: {str(e)}",
            "reference_nct_id": reference_nct_id
        }, ensure_ascii=False, indent=2)


@tool
def compare_two_trials(
    nct_id_1: str,
    nct_id_2: str,
    db_path: str = ".cache/clinical_trial_search_agent/milvus.db",
    collection_name: str = "clinical_trials"
) -> str:
    """
    对比两个临床试验的详细信息
    
    Args:
        nct_id_1: 第一个试验的NCT ID
        nct_id_2: 第二个试验的NCT ID
        db_path: 数据库文件路径
        collection_name: Collection名称
        
    Returns:
        str: JSON格式的对比结果
    """
    try:
        from pymilvus import MilvusClient
        
        client = MilvusClient(uri=db_path)
        
        if not client.has_collection(collection_name):
            client.close()
            return json.dumps({
                "status": "error",
                "error_type": "collection_not_found",
                "message": f"Collection {collection_name} 不存在"
            }, ensure_ascii=False, indent=2)
        
        # 获取两个试验的信息
        output_fields = [
            "nct_id", "title", "brief_summary", "eligibility_criteria",
            "phase", "status", "sponsor", "start_date", "completion_date",
            "conditions", "interventions", "url"
        ]
        
        trial_1 = client.query(
            collection_name=collection_name,
            filter=f'nct_id == "{nct_id_1}"',
            output_fields=output_fields,
            limit=1
        )
        
        trial_2 = client.query(
            collection_name=collection_name,
            filter=f'nct_id == "{nct_id_2}"',
            output_fields=output_fields,
            limit=1
        )
        
        client.close()
        
        if not trial_1:
            return json.dumps({
                "status": "error",
                "error_type": "trial_not_found",
                "message": f"试验 {nct_id_1} 不存在",
                "nct_id": nct_id_1
            }, ensure_ascii=False, indent=2)
        
        if not trial_2:
            return json.dumps({
                "status": "error",
                "error_type": "trial_not_found",
                "message": f"试验 {nct_id_2} 不存在",
                "nct_id": nct_id_2
            }, ensure_ascii=False, indent=2)
        
        t1 = trial_1[0]
        t2 = trial_2[0]
        
        # 生成对比
        comparison = {
            "basic_info": {
                "trial_1": {
                    "nct_id": t1.get("nct_id"),
                    "title": t1.get("title"),
                    "url": t1.get("url")
                },
                "trial_2": {
                    "nct_id": t2.get("nct_id"),
                    "title": t2.get("title"),
                    "url": t2.get("url")
                }
            },
            "phase_comparison": {
                "trial_1_phase": t1.get("phase"),
                "trial_2_phase": t2.get("phase"),
                "same_phase": t1.get("phase") == t2.get("phase")
            },
            "status_comparison": {
                "trial_1_status": t1.get("status"),
                "trial_2_status": t2.get("status"),
                "same_status": t1.get("status") == t2.get("status")
            },
            "sponsor_comparison": {
                "trial_1_sponsor": t1.get("sponsor"),
                "trial_2_sponsor": t2.get("sponsor"),
                "same_sponsor": t1.get("sponsor") == t2.get("sponsor")
            },
            "timeline_comparison": {
                "trial_1_start": t1.get("start_date"),
                "trial_2_start": t2.get("start_date"),
                "trial_1_completion": t1.get("completion_date"),
                "trial_2_completion": t2.get("completion_date")
            },
            "condition_comparison": {
                "trial_1_conditions": t1.get("conditions", "").split(", "),
                "trial_2_conditions": t2.get("conditions", "").split(", "),
                "common_conditions": list(
                    set(t1.get("conditions", "").split(", ")) & 
                    set(t2.get("conditions", "").split(", "))
                )
            },
            "intervention_comparison": {
                "trial_1_interventions": t1.get("interventions", "").split(", "),
                "trial_2_interventions": t2.get("interventions", "").split(", "),
                "common_interventions": list(
                    set(t1.get("interventions", "").split(", ")) & 
                    set(t2.get("interventions", "").split(", "))
                )
            }
        }
        
        return json.dumps({
            "status": "success",
            "nct_id_1": nct_id_1,
            "nct_id_2": nct_id_2,
            "comparison": comparison
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "comparison_error",
            "message": f"试验对比失败: {str(e)}",
            "nct_id_1": nct_id_1,
            "nct_id_2": nct_id_2
        }, ensure_ascii=False, indent=2)


@tool
def analyze_sponsor_portfolio(
    sponsor_name: str,
    db_path: str = ".cache/clinical_trial_search_agent/milvus.db",
    collection_name: str = "clinical_trials"
) -> str:
    """
    分析指定主办方的试验组合
    
    Args:
        sponsor_name: 主办方名称（支持模糊匹配）
        db_path: 数据库文件路径
        collection_name: Collection名称
        
    Returns:
        str: JSON格式的主办方试验组合分析
    """
    try:
        from pymilvus import MilvusClient
        
        client = MilvusClient(uri=db_path)
        
        if not client.has_collection(collection_name):
            client.close()
            return json.dumps({
                "status": "error",
                "error_type": "collection_not_found",
                "message": f"Collection {collection_name} 不存在"
            }, ensure_ascii=False, indent=2)
        
        # 查询该主办方的所有试验
        trials = client.query(
            collection_name=collection_name,
            filter=f'sponsor like "%{sponsor_name}%"',
            output_fields=[
                "nct_id", "title", "phase", "status", "start_date",
                "completion_date", "conditions", "interventions", "url"
            ],
            limit=1000
        )
        
        client.close()
        
        if not trials:
            return json.dumps({
                "status": "success",
                "sponsor_name": sponsor_name,
                "total_trials": 0,
                "message": "未找到该主办方的试验"
            }, ensure_ascii=False, indent=2)
        
        # 统计分析
        phase_dist = {}
        status_dist = {}
        conditions_set = set()
        interventions_set = set()
        
        for trial in trials:
            phase = trial.get("phase", "N/A")
            status = trial.get("status", "Unknown")
            
            phase_dist[phase] = phase_dist.get(phase, 0) + 1
            status_dist[status] = status_dist.get(status, 0) + 1
            
            conditions = trial.get("conditions", "").split(", ")
            interventions = trial.get("interventions", "").split(", ")
            
            conditions_set.update([c for c in conditions if c])
            interventions_set.update([i for i in interventions if i])
        
        return json.dumps({
            "status": "success",
            "sponsor_name": sponsor_name,
            "total_trials": len(trials),
            "phase_distribution": phase_dist,
            "status_distribution": status_dist,
            "unique_conditions": len(conditions_set),
            "unique_interventions": len(interventions_set),
            "top_conditions": list(conditions_set)[:10],
            "top_interventions": list(interventions_set)[:10],
            "trials": [
                {
                    "nct_id": t.get("nct_id"),
                    "title": t.get("title"),
                    "phase": t.get("phase"),
                    "status": t.get("status"),
                    "url": t.get("url")
                }
                for t in trials
            ]
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "portfolio_analysis_error",
            "message": f"主办方试验组合分析失败: {str(e)}",
            "sponsor_name": sponsor_name
        }, ensure_ascii=False, indent=2)
