#!/usr/bin/env python3
"""
Milvus Lite向量数据库管理工具

管理Milvus Lite数据库的生命周期，包括初始化、连接、Collection管理等
"""

import json
import os
from typing import Dict, List, Any, Optional
from pathlib import Path
from strands import tool


@tool
def initialize_milvus_database(
    db_path: str = ".cache/clinical_trial_search_agent/milvus.db",
    collection_name: str = "clinical_trials"
) -> str:
    """
    初始化Milvus Lite数据库和Collection
    
    Args:
        db_path: 数据库文件路径
        collection_name: Collection名称
        
    Returns:
        str: JSON格式的初始化结果
    """
    try:
        from pymilvus import MilvusClient, DataType
        
        # 创建数据库目录
        db_dir = os.path.dirname(db_path)
        os.makedirs(db_dir, exist_ok=True)
        
        # 检查数据库是否已存在
        db_exists = os.path.exists(db_path)
        
        # 连接到Milvus Lite
        client = MilvusClient(uri=db_path)
        
        # 检查Collection是否存在
        has_collection = client.has_collection(collection_name)
        
        if not has_collection:
            # 创建Collection Schema
            schema = MilvusClient.create_schema(
                auto_id=True,
                enable_dynamic_field=True
            )
            
            # 添加字段
            schema.add_field(field_name="id", datatype=DataType.INT64, is_primary=True)
            schema.add_field(field_name="nct_id", datatype=DataType.VARCHAR, max_length=20)
            schema.add_field(field_name="title", datatype=DataType.VARCHAR, max_length=1000)
            schema.add_field(field_name="brief_summary", datatype=DataType.VARCHAR, max_length=5000)
            schema.add_field(field_name="eligibility_criteria", datatype=DataType.VARCHAR, max_length=10000)
            schema.add_field(field_name="phase", datatype=DataType.VARCHAR, max_length=50)
            schema.add_field(field_name="status", datatype=DataType.VARCHAR, max_length=100)
            schema.add_field(field_name="sponsor", datatype=DataType.VARCHAR, max_length=500)
            schema.add_field(field_name="start_date", datatype=DataType.VARCHAR, max_length=50)
            schema.add_field(field_name="completion_date", datatype=DataType.VARCHAR, max_length=50)
            schema.add_field(field_name="conditions", datatype=DataType.VARCHAR, max_length=2000)
            schema.add_field(field_name="interventions", datatype=DataType.VARCHAR, max_length=2000)
            schema.add_field(field_name="url", datatype=DataType.VARCHAR, max_length=200)
            schema.add_field(field_name="embedding_vector", datatype=DataType.FLOAT_VECTOR, dim=1024)
            
            # 创建索引参数
            index_params = client.prepare_index_params()
            index_params.add_index(
                field_name="embedding_vector",
                index_type="FLAT",  # FLAT索引适合小规模数据
                metric_type="COSINE"
            )
            
            # 创建Collection
            client.create_collection(
                collection_name=collection_name,
                schema=schema,
                index_params=index_params
            )
        
        # 获取Collection信息
        stats = client.get_collection_stats(collection_name)
        
        client.close()
        
        return json.dumps({
            "status": "success",
            "db_path": db_path,
            "db_exists_before": db_exists,
            "collection_name": collection_name,
            "collection_existed": has_collection,
            "collection_created": not has_collection,
            "row_count": stats.get("row_count", 0),
            "index_type": "FLAT",
            "metric_type": "COSINE",
            "vector_dimension": 1024
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "initialization_error",
            "message": f"数据库初始化失败: {str(e)}",
            "db_path": db_path,
            "collection_name": collection_name
        }, ensure_ascii=False, indent=2)


@tool
def connect_milvus_database(
    db_path: str = ".cache/clinical_trial_search_agent/milvus.db"
) -> str:
    """
    连接到Milvus Lite数据库并检查状态
    
    Args:
        db_path: 数据库文件路径
        
    Returns:
        str: JSON格式的连接状态
    """
    try:
        from pymilvus import MilvusClient
        
        # 检查数据库文件是否存在
        if not os.path.exists(db_path):
            return json.dumps({
                "status": "error",
                "error_type": "database_not_found",
                "message": "数据库文件不存在，请先初始化",
                "db_path": db_path
            }, ensure_ascii=False, indent=2)
        
        # 连接到数据库
        client = MilvusClient(uri=db_path)
        
        # 列出所有Collection
        collections = client.list_collections()
        
        client.close()
        
        return json.dumps({
            "status": "success",
            "db_path": db_path,
            "db_size_mb": os.path.getsize(db_path) / (1024 * 1024),
            "collections": collections,
            "collection_count": len(collections)
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "connection_error",
            "message": f"数据库连接失败: {str(e)}",
            "db_path": db_path
        }, ensure_ascii=False, indent=2)


@tool
def insert_trial_vectors(
    trial_vectors: List[Dict[str, Any]],
    db_path: str = ".cache/clinical_trial_search_agent/milvus.db",
    collection_name: str = "clinical_trials",
    check_duplicates: bool = True
) -> str:
    """
    插入临床试验向量到Milvus数据库
    
    Args:
        trial_vectors: 临床试验向量列表，每个包含trial_data和embedding
        db_path: 数据库文件路径
        collection_name: Collection名称
        check_duplicates: 是否检查重复（通过NCT ID）
        
    Returns:
        str: JSON格式的插入结果
    """
    try:
        from pymilvus import MilvusClient
        
        if not trial_vectors:
            return json.dumps({
                "status": "error",
                "error_type": "invalid_input",
                "message": "试验向量列表不能为空"
            }, ensure_ascii=False, indent=2)
        
        # 连接到数据库
        client = MilvusClient(uri=db_path)
        
        # 检查Collection是否存在
        if not client.has_collection(collection_name):
            client.close()
            return json.dumps({
                "status": "error",
                "error_type": "collection_not_found",
                "message": f"Collection {collection_name} 不存在，请先初始化数据库",
                "collection_name": collection_name
            }, ensure_ascii=False, indent=2)
        
        # 去重处理
        nct_ids_to_insert = []
        data_to_insert = []
        skipped_count = 0
        
        for item in trial_vectors:
            trial_data = item.get("trial_data", {})
            embedding = item.get("embedding", [])
            nct_id = trial_data.get("nct_id", "")
            
            if not nct_id or not embedding:
                skipped_count += 1
                continue
            
            # 检查是否已存在
            if check_duplicates:
                existing = client.query(
                    collection_name=collection_name,
                    filter=f'nct_id == "{nct_id}"',
                    output_fields=["nct_id"],
                    limit=1
                )
                if existing:
                    skipped_count += 1
                    continue
            
            # 准备插入数据
            conditions_str = ", ".join(trial_data.get("conditions", []))
            interventions_str = ", ".join(trial_data.get("interventions", []))
            
            data_to_insert.append({
                "nct_id": nct_id,
                "title": trial_data.get("title", "")[:1000],
                "brief_summary": trial_data.get("brief_summary", "")[:5000],
                "eligibility_criteria": trial_data.get("eligibility_criteria", "")[:10000],
                "phase": trial_data.get("phase", "N/A")[:50],
                "status": trial_data.get("status", "")[:100],
                "sponsor": trial_data.get("sponsor", "")[:500],
                "start_date": trial_data.get("start_date", "")[:50],
                "completion_date": trial_data.get("completion_date", "")[:50],
                "conditions": conditions_str[:2000],
                "interventions": interventions_str[:2000],
                "url": trial_data.get("url", "")[:200],
                "embedding_vector": embedding
            })
            nct_ids_to_insert.append(nct_id)
        
        # 批量插入
        inserted_count = 0
        if data_to_insert:
            insert_result = client.insert(
                collection_name=collection_name,
                data=data_to_insert
            )
            inserted_count = insert_result.get("insert_count", len(data_to_insert))
        
        # 获取Collection统计
        stats = client.get_collection_stats(collection_name)
        
        client.close()
        
        return json.dumps({
            "status": "success",
            "total_input": len(trial_vectors),
            "inserted_count": inserted_count,
            "skipped_count": skipped_count,
            "nct_ids_inserted": nct_ids_to_insert,
            "collection_total_rows": stats.get("row_count", 0),
            "check_duplicates": check_duplicates
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "insertion_error",
            "message": f"向量插入失败: {str(e)}",
            "total_input": len(trial_vectors)
        }, ensure_ascii=False, indent=2)


@tool
def check_trial_exists(
    nct_id: str,
    db_path: str = ".cache/clinical_trial_search_agent/milvus.db",
    collection_name: str = "clinical_trials"
) -> str:
    """
    检查指定NCT ID是否已存在于数据库中
    
    Args:
        nct_id: 临床试验NCT ID
        db_path: 数据库文件路径
        collection_name: Collection名称
        
    Returns:
        str: JSON格式的检查结果
    """
    try:
        from pymilvus import MilvusClient
        
        client = MilvusClient(uri=db_path)
        
        if not client.has_collection(collection_name):
            client.close()
            return json.dumps({
                "status": "error",
                "error_type": "collection_not_found",
                "message": f"Collection {collection_name} 不存在",
                "nct_id": nct_id,
                "exists": False
            }, ensure_ascii=False, indent=2)
        
        # 查询是否存在
        results = client.query(
            collection_name=collection_name,
            filter=f'nct_id == "{nct_id}"',
            output_fields=["nct_id", "title", "phase", "status"],
            limit=1
        )
        
        client.close()
        
        exists = len(results) > 0
        
        return json.dumps({
            "status": "success",
            "nct_id": nct_id,
            "exists": exists,
            "data": results[0] if exists else None
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "query_error",
            "message": f"查询失败: {str(e)}",
            "nct_id": nct_id
        }, ensure_ascii=False, indent=2)


@tool
def get_database_statistics(
    db_path: str = ".cache/clinical_trial_search_agent/milvus.db",
    collection_name: str = "clinical_trials"
) -> str:
    """
    获取数据库统计信息
    
    Args:
        db_path: 数据库文件路径
        collection_name: Collection名称
        
    Returns:
        str: JSON格式的统计信息
    """
    try:
        from pymilvus import MilvusClient
        
        if not os.path.exists(db_path):
            return json.dumps({
                "status": "error",
                "error_type": "database_not_found",
                "message": "数据库文件不存在",
                "db_path": db_path
            }, ensure_ascii=False, indent=2)
        
        client = MilvusClient(uri=db_path)
        
        if not client.has_collection(collection_name):
            client.close()
            return json.dumps({
                "status": "error",
                "error_type": "collection_not_found",
                "message": f"Collection {collection_name} 不存在",
                "db_path": db_path
            }, ensure_ascii=False, indent=2)
        
        # 获取统计信息
        stats = client.get_collection_stats(collection_name)
        
        # 统计不同阶段的试验数量
        phase_stats = {}
        for phase in ["PHASE1", "PHASE2", "PHASE3", "PHASE4", "N/A"]:
            results = client.query(
                collection_name=collection_name,
                filter=f'phase == "{phase}"',
                output_fields=["nct_id"],
                limit=10000
            )
            phase_stats[phase] = len(results)
        
        # 统计不同状态的试验数量
        status_stats = {}
        for status in ["RECRUITING", "ACTIVE_NOT_RECRUITING", "COMPLETED", "TERMINATED"]:
            results = client.query(
                collection_name=collection_name,
                filter=f'status == "{status}"',
                output_fields=["nct_id"],
                limit=10000
            )
            status_stats[status] = len(results)
        
        client.close()
        
        return json.dumps({
            "status": "success",
            "db_path": db_path,
            "db_size_mb": os.path.getsize(db_path) / (1024 * 1024),
            "collection_name": collection_name,
            "total_rows": stats.get("row_count", 0),
            "phase_distribution": phase_stats,
            "status_distribution": status_stats
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "statistics_error",
            "message": f"获取统计信息失败: {str(e)}",
            "db_path": db_path
        }, ensure_ascii=False, indent=2)


@tool
def delete_trials_by_nct_ids(
    nct_ids: List[str],
    db_path: str = ".cache/clinical_trial_search_agent/milvus.db",
    collection_name: str = "clinical_trials"
) -> str:
    """
    根据NCT ID列表删除临床试验数据
    
    Args:
        nct_ids: 要删除的NCT ID列表
        db_path: 数据库文件路径
        collection_name: Collection名称
        
    Returns:
        str: JSON格式的删除结果
    """
    try:
        from pymilvus import MilvusClient
        
        if not nct_ids:
            return json.dumps({
                "status": "error",
                "error_type": "invalid_input",
                "message": "NCT ID列表不能为空"
            }, ensure_ascii=False, indent=2)
        
        client = MilvusClient(uri=db_path)
        
        if not client.has_collection(collection_name):
            client.close()
            return json.dumps({
                "status": "error",
                "error_type": "collection_not_found",
                "message": f"Collection {collection_name} 不存在"
            }, ensure_ascii=False, indent=2)
        
        # 批量删除
        deleted_count = 0
        not_found = []
        
        for nct_id in nct_ids:
            # 查询是否存在
            results = client.query(
                collection_name=collection_name,
                filter=f'nct_id == "{nct_id}"',
                output_fields=["id"],
                limit=1
            )
            
            if results:
                # 删除
                client.delete(
                    collection_name=collection_name,
                    filter=f'nct_id == "{nct_id}"'
                )
                deleted_count += 1
            else:
                not_found.append(nct_id)
        
        client.close()
        
        return json.dumps({
            "status": "success",
            "total_requested": len(nct_ids),
            "deleted_count": deleted_count,
            "not_found_count": len(not_found),
            "not_found_ids": not_found if not_found else None
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "deletion_error",
            "message": f"删除失败: {str(e)}",
            "total_requested": len(nct_ids)
        }, ensure_ascii=False, indent=2)


@tool
def clear_collection(
    db_path: str = ".cache/clinical_trial_search_agent/milvus.db",
    collection_name: str = "clinical_trials",
    confirm: bool = False
) -> str:
    """
    清空Collection中的所有数据
    
    Args:
        db_path: 数据库文件路径
        collection_name: Collection名称
        confirm: 确认清空操作（必须为True才执行）
        
    Returns:
        str: JSON格式的清空结果
    """
    try:
        from pymilvus import MilvusClient
        
        if not confirm:
            return json.dumps({
                "status": "error",
                "error_type": "confirmation_required",
                "message": "必须设置confirm=True才能执行清空操作",
                "collection_name": collection_name
            }, ensure_ascii=False, indent=2)
        
        client = MilvusClient(uri=db_path)
        
        if not client.has_collection(collection_name):
            client.close()
            return json.dumps({
                "status": "error",
                "error_type": "collection_not_found",
                "message": f"Collection {collection_name} 不存在"
            }, ensure_ascii=False, indent=2)
        
        # 获取清空前的行数
        stats_before = client.get_collection_stats(collection_name)
        rows_before = stats_before.get("row_count", 0)
        
        # 删除Collection
        client.drop_collection(collection_name)
        
        client.close()
        
        return json.dumps({
            "status": "success",
            "collection_name": collection_name,
            "rows_deleted": rows_before,
            "message": f"已清空Collection {collection_name}，删除了 {rows_before} 条记录"
        }, ensure_ascii=False, indent=2)
        
    except Exception as e:
        return json.dumps({
            "status": "error",
            "error_type": "clear_error",
            "message": f"清空失败: {str(e)}",
            "collection_name": collection_name
        }, ensure_ascii=False, indent=2)
